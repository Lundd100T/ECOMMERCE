    <!-- Footer -->
    <footer class="bg-dark text-white text-center py-3">
        <p>&copy; 2024 MyShop. All rights reserved.</p>
        <nav>
            <a href="#" class="text-white">Privacy Policy</a> | 
            <a href="#" class="text-white">Terms & Conditions</a>
        </nav>
    </footer>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>