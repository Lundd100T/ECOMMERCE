<?php
define('BASE_URL', "http://ecommerce.test/");
define('ROOT_DIR', $_SERVER["DOCUMENT_ROOT"]. "/");
?>